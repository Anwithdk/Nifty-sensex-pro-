# NIFTY & SENSEX Signal Pro — Groww + Cloudflare Worker

This is the new single-Worker version. It keeps the Groww access token server-side as a Cloudflare Worker secret and serves the mobile dashboard from the same Worker.

## What it does
- Real Groww LTP for NIFTY and SENSEX
- Real 1-minute and 5-minute candles
- RSI, EMA9/EMA21, VWAP and MACD
- CALL-SIDE / PUT-SIDE / WAIT signal logic
- 5-second dashboard refresh
- No synthetic/demo prices
- No order placement

Groww's API docs confirm live LTP/quote and historical candle APIs, including 1-minute and 5-minute intervals. See the official docs before using the system.

## Cloudflare setup from iPhone
1. Cloudflare Dashboard → Workers & Pages → Create → Worker.
2. Create/deploy a Worker, then open **Edit code**.
3. Replace the Worker code with `worker.js` from this ZIP.
4. Deploy.
5. Open Worker **Settings → Variables and Secrets**.
6. Add a secret named exactly:
   `GROWW_ACCESS_TOKEN`
7. Paste your Groww **Access Token** as the secret value. Never paste it into the HTML or send it in chat.
8. Save/deploy again.
9. Open the Worker URL. It should show **LIVE — Groww feed connected**.

## Important
- Groww access tokens expire daily according to the current Groww documentation, so the secret may need updating.
- Groww API access requires an active Trading API subscription.
- This dashboard is an analytical aid. It does not guarantee profit and does not place trades.
- For options, the next upgrade can add expiry/strike selection and option-chain confirmation using Groww's option-chain API.
