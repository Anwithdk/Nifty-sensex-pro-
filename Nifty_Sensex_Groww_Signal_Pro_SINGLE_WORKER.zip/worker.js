const GROWW_BASE = 'https://api.groww.in/v1';

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Cache-Control': 'no-store'
  };
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', ...corsHeaders() }
  });
}

async function growwFetch(path, token) {
  const r = await fetch(GROWW_BASE + path, {
    headers: {
      Accept: 'application/json',
      Authorization: `Bearer ${token}`,
      'X-API-VERSION': '1.0'
    }
  });
  const text = await r.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { raw: text }; }
  if (!r.ok || body.status === 'FAILURE') {
    const msg = body?.error?.message || body?.message || `Groww HTTP ${r.status}`;
    throw new Error(msg);
  }
  return body;
}

function sma(values, n) {
  if (values.length < n) return null;
  const a = values.slice(-n);
  return a.reduce((x, y) => x + y, 0) / n;
}

function ema(values, n) {
  if (values.length < n) return null;
  const k = 2 / (n + 1);
  let e = values[0];
  for (let i = 1; i < values.length; i++) e = values[i] * k + e * (1 - k);
  return e;
}

function rsi(values, n = 14) {
  if (values.length < n + 1) return null;
  let gains = 0, losses = 0;
  for (let i = 1; i <= n; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0) gains += d; else losses -= d;
  }
  let avgGain = gains / n, avgLoss = losses / n;
  for (let i = n + 1; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    const g = Math.max(d, 0), l = Math.max(-d, 0);
    avgGain = (avgGain * (n - 1) + g) / n;
    avgLoss = (avgLoss * (n - 1) + l) / n;
  }
  if (avgLoss === 0) return 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

function macd(values) {
  if (values.length < 35) return null;
  const fast = ema(values, 12), slow = ema(values, 26);
  return fast - slow;
}

function vwap(candles) {
  let pv = 0, vol = 0;
  for (const c of candles) {
    const tp = (c[2] + c[3] + c[4]) / 3;
    const v = Number(c[5] || 0);
    pv += tp * v; vol += v;
  }
  return vol ? pv / vol : null;
}

function parseCandles(payload) {
  return (payload?.candles || []).filter(x => Array.isArray(x) && x.length >= 6)
    .map(x => [Number.isFinite(Number(x[0])) ? Number(x[0]) : Date.parse(x[0]), Number(x[1]), Number(x[2]), Number(x[3]), Number(x[4]), Number(x[5] || 0)]);
}

function scoreSignal(c1, c5, ltp) {
  const closes1 = c1.map(x => x[4]);
  const closes5 = c5.map(x => x[4]);
  const e9 = ema(closes1, 9), e21 = ema(closes1, 21), e5 = ema(closes5, 9), e5b = ema(closes5, 21);
  const r = rsi(closes1, 14), m = macd(closes1), vw = vwap(c1.slice(-75));
  let bull = 0, bear = 0, reasons = [];
  if (e9 != null && e21 != null) { if (e9 > e21) { bull++; reasons.push('1m EMA9 > EMA21'); } else { bear++; reasons.push('1m EMA9 < EMA21'); } }
  if (e5 != null && e5b != null) { if (e5 > e5b) { bull++; reasons.push('5m trend up'); } else { bear++; reasons.push('5m trend down'); } }
  if (r != null) { if (r >= 55 && r <= 72) { bull++; reasons.push(`RSI ${r.toFixed(1)} bullish`); } else if (r <= 45 && r >= 28) { bear++; reasons.push(`RSI ${r.toFixed(1)} bearish`); } }
  if (vw != null) { if (ltp > vw) { bull++; reasons.push('price above VWAP'); } else { bear++; reasons.push('price below VWAP'); } }
  if (m != null) { if (m > 0) { bull++; reasons.push('MACD positive'); } else { bear++; reasons.push('MACD negative'); } }
  const high = Math.max(...c1.slice(-10).map(x => x[2]));
  const low = Math.min(...c1.slice(-10).map(x => x[3]));
  let signal = 'WAIT', confidence = Math.max(bull, bear) * 16;
  if (bull >= 4 && bull - bear >= 2 && ltp >= high * 0.9995) { signal = 'CALL-SIDE'; confidence = Math.min(92, 55 + bull * 7); reasons.push('near short-term breakout'); }
  else if (bear >= 4 && bear - bull >= 2 && ltp <= low * 1.0005) { signal = 'PUT-SIDE'; confidence = Math.min(92, 55 + bear * 7); reasons.push('near short-term breakdown'); }
  else { confidence = Math.min(74, 45 + Math.abs(bull - bear) * 8); }
  return { signal, confidence, bull, bear, rsi: r, ema9: e9, ema21: e21, vwap: vw, macd: m, reasons, high, low };
}

function optionSummary(chain, ltp) {
  const strikes = chain?.strikes || {};
  const rows = Object.entries(strikes).map(([k, v]) => ({ strike: Number(k), ...v })).filter(x => Number.isFinite(x.strike));
  let callOI = 0, putOI = 0, callVol = 0, putVol = 0;
  for (const r of rows) {
    const ce = r.ce || r.CE || r.call || {};
    const pe = r.pe || r.PE || r.put || {};
    callOI += Number(ce.open_interest || ce.oi || 0);
    putOI += Number(pe.open_interest || pe.oi || 0);
    callVol += Number(ce.volume || 0);
    putVol += Number(pe.volume || 0);
  }
  const pcr = callOI ? putOI / callOI : null;
  const nearest = rows.sort((a,b) => Math.abs(a.strike-ltp)-Math.abs(b.strike-ltp)).slice(0, 3);
  return { pcr, callOI, putOI, callVol, putVol, nearest };
}

async function getIndex(env, exchange, symbol) {
  const token = env.GROWW_ACCESS_TOKEN;
  if (!token) throw new Error('GROWW_ACCESS_TOKEN secret is not configured');
  const [ltpRes, candles1Res, candles5Res] = await Promise.all([
    growwFetch(`/live-data/ltp?segment=CASH&exchange_symbols=${exchange}_${symbol}`, token),
    growwFetch(`/historical/candles?exchange=${exchange}&segment=CASH&groww_symbol=${exchange}-${symbol}&start_time=${encodeURIComponent(new Date(Date.now()-2*24*3600*1000).toISOString().slice(0,10)+' 09:15:00')}&end_time=${encodeURIComponent(new Date().toISOString().slice(0,19).replace('T',' '))}&candle_interval=1minute`, token),
    growwFetch(`/historical/candles?exchange=${exchange}&segment=CASH&groww_symbol=${exchange}-${symbol}&start_time=${encodeURIComponent(new Date(Date.now()-5*24*3600*1000).toISOString().slice(0,10)+' 09:15:00')}&end_time=${encodeURIComponent(new Date().toISOString().slice(0,19).replace('T',' '))}&candle_interval=5minute`, token)
  ]);
  const ltp = Number(ltpRes?.payload?.[`${exchange}_${symbol}`]);
  const c1 = parseCandles(candles1Res.payload);
  const c5 = parseCandles(candles5Res.payload);
  const analysis = scoreSignal(c1, c5, ltp);
  return { symbol, exchange, ltp, candles1: c1.slice(-120), candles5: c5.slice(-80), analysis };
}

async function handleApi(request, env) {
  const url = new URL(request.url);
  if (url.pathname === '/api/market') {
    try {
      const [nifty, sensex] = await Promise.all([
        getIndex(env, 'NSE', 'NIFTY'),
        getIndex(env, 'BSE', 'SENSEX')
      ]);
      return json({ ok: true, ts: Date.now(), nifty, sensex });
    } catch (e) {
      return json({ ok: false, error: e.message }, 502);
    }
  }
  if (url.pathname === '/api/option-chain') {
    try {
      const token = env.GROWW_ACCESS_TOKEN;
      if (!token) throw new Error('GROWW_ACCESS_TOKEN secret is not configured');
      const underlying = (url.searchParams.get('underlying') || 'NIFTY').toUpperCase();
      const exchange = underlying === 'SENSEX' ? 'BSE' : 'NSE';
      const exp = url.searchParams.get('expiry');
      if (!exp) throw new Error('Missing expiry=YYYY-MM-DD');
      const chain = await growwFetch(`/option-chain/exchange/${exchange}/underlying/${underlying}?expiry_date=${encodeURIComponent(exp)}`, token);
      return json({ ok: true, underlying, expiry: exp, summary: optionSummary(chain.payload, Number(chain.payload?.underlying_ltp)), raw: chain.payload });
    } catch (e) { return json({ ok: false, error: e.message }, 502); }
  }
  return new Response('Not found', { status: 404, headers: corsHeaders() });
}

const HTML = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0a0d14"><title>NIFTY SENSEX Signal Pro</title><style>
*{box-sizing:border-box}body{margin:0;background:#070a10;color:#eef2ff;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}main{max-width:760px;margin:auto;padding:16px 14px 40px}.top{display:flex;justify-content:space-between;align-items:center}.brand{font-size:22px;font-weight:800}.pill{padding:7px 10px;border-radius:999px;background:#151a25;color:#9aa7bd;font-size:12px}.status{margin:14px 0;padding:13px;border:1px solid #202838;border-radius:14px;background:#0d1119}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.card{background:#0d1119;border:1px solid #202838;border-radius:16px;padding:14px}.name{font-size:13px;color:#8e9bb2}.price{font-size:27px;font-weight:800;margin-top:5px}.signal{margin-top:12px;padding:14px;border-radius:13px;background:#151b27}.sig{font-size:22px;font-weight:900}.meta{font-size:12px;color:#9aa7bd;margin-top:5px}.row{display:flex;justify-content:space-between;margin:8px 0;font-size:13px}.reason{color:#c7d0e3;font-size:12px;line-height:1.45;margin-top:10px}.bar{height:7px;border-radius:9px;background:#202838;overflow:hidden}.bar i{display:block;height:100%;width:0;background:#7c8cff}.controls{display:flex;gap:8px;margin:14px 0}.btn{border:1px solid #2a3447;background:#111722;color:#fff;border-radius:11px;padding:10px 13px;font-weight:700}.foot{color:#728099;font-size:11px;line-height:1.5;margin-top:14px}.good{color:#63e6a7}.warn{color:#ffd166}.bad{color:#ff7b7b}@media(max-width:560px){.grid{grid-template-columns:1fr}.brand{font-size:20px}}
</style></head><body><main><div class="top"><div class="brand">NIFTY & SENSEX ⚡ Signal Pro</div><div class="pill" id="mode">LIVE</div></div><div class="status"><div id="status">Connecting to Groww…</div><div class="meta" id="updated">—</div></div><div class="controls"><button class="btn" onclick="load()">↻ Refresh</button><button class="btn" onclick="auto()" id="auto">Auto: ON</button></div><div class="grid"><section class="card"><div class="name">NIFTY 50</div><div class="price" id="nprice">—</div><div class="meta" id="nchange">—</div><div class="signal"><div class="sig" id="nsig">WAIT</div><div class="meta" id="nconf">Confidence —</div><div class="bar"><i id="nbar"></i></div><div class="reason" id="nreason">Waiting for live candles…</div></div><div class="row"><span>RSI</span><b id="nrsi">—</b></div><div class="row"><span>VWAP</span><b id="nvwap">—</b></div><div class="row"><span>1m EMA</span><b id="nema">—</b></div></section><section class="card"><div class="name">SENSEX</div><div class="price" id="sprice">—</div><div class="meta" id="schange">—</div><div class="signal"><div class="sig" id="ssig">WAIT</div><div class="meta" id="sconf">Confidence —</div><div class="bar"><i id="sbar"></i></div><div class="reason" id="sreason">Waiting for live candles…</div></div><div class="row"><span>RSI</span><b id="srsi">—</b></div><div class="row"><span>VWAP</span><b id="svwap">—</b></div><div class="row"><span>1m EMA</span><b id="sema">—</b></div></section></div><div class="card" style="margin-top:12px"><b>How this version decides</b><div class="reason">It combines 1-minute and 5-minute EMA trend, RSI, VWAP, MACD and short-term breakout/breakdown structure. It only prints CALL-SIDE or PUT-SIDE when multiple conditions agree; otherwise it stays WAIT. This is a signal aid, not a guaranteed-profit system.</div></div><div class="foot">No synthetic prices. Data comes through your Cloudflare Worker using your Groww API access token stored as a secret. Groww access tokens expire daily, so update the secret when required.</div></main><script>
let timer=null, enabled=true;function $(id){return document.getElementById(id)}function fmt(n){return Number.isFinite(n)?n.toLocaleString('en-IN',{maximumFractionDigits:2}):'—'}function paint(p,pre){$(pre+'price').textContent=fmt(p.ltp);const a=p.analysis;$(pre+'sig').textContent=a.signal;$(pre+'conf').textContent='Confidence '+a.confidence+'%';$(pre+'bar').style.width=a.confidence+'%';$(pre+'reason').textContent=a.reasons.join(' • ');$(pre+'rsi').textContent=a.rsi==null?'—':a.rsi.toFixed(1);$(pre+'vwap').textContent=fmt(a.vwap);$(pre+'ema').textContent=a.ema9&&a.ema21?(a.ema9>a.ema21?'BULLISH':'BEARISH'):'—';$(pre+'sig').className='sig '+(a.signal==='CALL-SIDE'?'good':a.signal==='PUT-SIDE'?'bad':'warn')}async function load(){try{$('status').textContent='Fetching Groww live data…';const r=await fetch('/api/market',{cache:'no-store'});const d=await r.json();if(!d.ok)throw new Error(d.error);paint(d.nifty,'n');paint(d.sensex,'s');$('status').textContent='● LIVE — Groww feed connected';$('status').className='good';$('updated').textContent='Updated '+new Date(d.ts).toLocaleTimeString('en-IN')}catch(e){$('status').textContent='⚠ FEED ERROR — '+e.message;$('status').className='bad';$('updated').textContent='No live signal generated'}}function auto(){enabled=!enabled;$('auto').textContent='Auto: '+(enabled?'ON':'OFF');if(timer)clearInterval(timer);if(enabled){load();timer=setInterval(load,5000)}}load();timer=setInterval(load,5000);</script></body></html>`;

export default { async fetch(request, env) { if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders() }); const url = new URL(request.url); if (url.pathname.startsWith('/api/')) return handleApi(request, env); return new Response(HTML, { headers: { 'Content-Type':'text/html; charset=utf-8', 'Cache-Control':'no-store' } }); } };
